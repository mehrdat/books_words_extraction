# books_words_extraction

This program will help to extract the uncommon words of the english books and docs for non-english speaker users.

The extractions is from PDF and Epub at the moment. This app will translate those uncoomon words and will put them in a list. So if you want to have a look what words could be in the book that you might need the translation this app will be very helpful.
ATM it just tanslate from English to Persian. But any other languages could be planted in it. 

