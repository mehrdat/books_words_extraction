from setuptools import setup
# Call setup function
setup(
author="Mehrdat",
description="An app to extract uncommon English words to translate hem in any book.",
name="BookTra",
version="0.1.0",
#python_version=(">=10.0")
install_requires=['pandas','spacy',],
)